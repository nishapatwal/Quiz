 

(function () {
  'use strict';
 
  const TIME_PER_QUESTION = 90; 
  const HIGH_SCORE_THRESHOLD = 80;  

   
  const QUESTIONS = [
    {
      text: 'What is the capital of France?',
      options: ['London', 'Paris', 'Berlin', 'Madrid'],
      correctIndex: 1
    },
    {
      text: 'Which planet is known as the Red Planet?',
      options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
      correctIndex: 1
    },
    {
      text: 'What is the largest ocean on Earth?',
      options: ['Atlantic', 'Indian', 'Arctic', 'Pacific'],
      correctIndex: 3
    },
    {
      text: 'In which year did World War II end?',
      options: ['2026', '1944', '1945', '5098'],
      correctIndex: 2
    },
    {
      text: 'What is the chemical symbol for gold?',
      options: ['Go', 'Gd', 'Au', 'Ag'],
      correctIndex: 2
    },
    {
      text: 'Which programming language is used for adding intractivity to the web page?',
      options: ['Python', 'Java', 'JavaScript', 'C++'],
      correctIndex: 2
    },
    {
      text: 'Who wrote "Romeo and Juliet"?',
      options: ['Nisha Patwal', 'William Shakespeare', 'Vansh', 'Harsh'],
      correctIndex: 1
    },
    {
      text: 'What is the smallest prime number?',
      options: ['0', '1', '2', '3'],
      correctIndex: 2
    },
    {
      text: 'Which country is home to the kangaroo?',
      options: ['New Zealand', 'South Africa', 'Australia', 'India'],
      correctIndex: 2
    },
    {
      text: 'What does CPU stand for?',
      options: ['Central Processing Unit', 'Computer Personal Unit', 'Central Program Utility', 'Central Processor Unifier'],
      correctIndex: 0
    }
  ];

  // ----- State -----
  let state = {
    currentIndex: 0,
    score: 0,
    answered: false,
    timeLeft: TIME_PER_QUESTION,
    timerId: null,
    userAnswers: [] 
  };

  
  let dom = {};

  /**
   * Show only the screen with the given id; hide others.
   * @param {string} screenId - Id of the screen to show ('start-screen' | 'quiz-screen' | 'results-screen')
   */
  function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(function (el) {
      el.classList.remove('active');
      el.classList.add('hidden');
    });
    var screen = document.getElementById(screenId);
    if (screen) {
      screen.classList.remove('hidden');
      screen.classList.add('active');
    }
  }

  
  function resetQuiz() {
    clearInterval(state.timerId);
    state.timerId = null;
    state.currentIndex = 0;
    state.score = 0;
    state.answered = false;
    state.timeLeft = TIME_PER_QUESTION;
    state.userAnswers = [];
  }

  /**
   * Update circular timer and progress bar (CSS variables).
   * @param {number} secondsLeft - Seconds remaining
   */
  function updateTimerDisplay(secondsLeft) {
    var progress = (secondsLeft / TIME_PER_QUESTION) * 100;
    var timerWrap = document.getElementById('timer-wrap');
    if (timerWrap) {
      timerWrap.style.setProperty('--timer-progress', progress);
      timerWrap.style.setProperty('--timer-color', progress > 30 ? 'var(--timer-full)' : 'var(--timer-low)');
    }
    var label = document.getElementById('timer-label');
    if (label) {
      var m = Math.floor(secondsLeft / 60);
      var s = secondsLeft % 60;
      label.textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    }
  }

  /**
   * Start the per-question countdown; on 0, advance or end quiz.
   */
  function startQuestionTimer() {
    state.timeLeft = TIME_PER_QUESTION;
    state.answered = false;
    updateTimerDisplay(state.timeLeft);

    state.timerId = setInterval(function () {
      state.timeLeft--;
      updateTimerDisplay(state.timeLeft);
      if (state.timeLeft <= 0) {
        clearInterval(state.timerId);
        state.timerId = null;
        onTimeout();
      }
    }, 1000);
  }

  /**
   * Called when timer hits 0: record no answer, show feedback, then advance.
   */
  function onTimeout() {
    if (state.answered) return;
    state.answered = true;
    var q = QUESTIONS[state.currentIndex];
    state.userAnswers.push({ correct: false, correctIndex: q.correctIndex, selectedIndex: -1 });
    showFeedback(false, q.correctIndex);
    updateScoreDisplay();
    scheduleNext();
  }

  /**
   * Show correct/wrong feedback and optional correct answer.
   * @param {boolean} correct
   * @param {number} correctIndex - Index of correct option (for "Wrong! Correct: B")
   */
  function showFeedback(correct, correctIndex) {
    var optionsContainer = document.getElementById('options');
    if (!optionsContainer) return;

    var labels = optionsContainer.querySelectorAll('.option');
    labels.forEach(function (opt, i) {
      opt.classList.add('disabled');
      if (i === correctIndex) opt.classList.add('correct');
      else if (opt.classList.contains('selected') && !correct) opt.classList.add('wrong');
    });

    var feedbackEl = document.getElementById('feedback');
    if (feedbackEl) {
      feedbackEl.classList.remove('correct-msg', 'wrong-msg');
      feedbackEl.classList.add(correct ? 'correct-msg' : 'wrong-msg');
      var optionLabel = String.fromCharCode(65 + correctIndex);
      feedbackEl.textContent = correct
        ? 'Correct!'
        : 'Wrong! Correct answer: ' + optionLabel + ') ' + QUESTIONS[state.currentIndex].options[correctIndex];
      feedbackEl.style.display = 'block';
    }
  }


  function scheduleNext() {
    var nextBtn = document.getElementById('next-btn');
    if (nextBtn) nextBtn.disabled = true;

    setTimeout(function () {
      state.currentIndex++;
      if (state.currentIndex >= QUESTIONS.length) {
        showResults();
      } else {
        renderQuestion();
        startQuestionTimer();
      }
    }, 1500);
  }


  function updateScoreDisplay() {
    var scoreEl = document.getElementById('score');
    if (scoreEl) scoreEl.textContent = 'Score: ' + state.score + '/' + (state.currentIndex + 1);
  }


  function renderQuestion() {
    var q = QUESTIONS[state.currentIndex];
    if (!q) return;

    var questionEl = document.getElementById('question');
    var optionsEl = document.getElementById('options');
    var feedbackEl = document.getElementById('feedback');
    var nextBtn = document.getElementById('next-btn');
    var progressFill = document.getElementById('progress-bar-fill');

    if (questionEl) questionEl.textContent = (state.currentIndex + 1) + '. ' + q.text;
    if (feedbackEl) feedbackEl.style.display = 'none';
    if (nextBtn) nextBtn.disabled = true;

     
    var progressPct = (state.currentIndex / QUESTIONS.length) * 100;
    if (progressFill) progressFill.style.setProperty('--progress-width', progressPct + '%');

    optionsEl.innerHTML = '';
    q.options.forEach(function (opt, i) {
      var label = document.createElement('label');
      label.className = 'option';
      var id = 'opt-' + state.currentIndex + '-' + i;
      var radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'answer';
      radio.value = i;
      radio.id = id;
      radio.addEventListener('change', onOptionSelect);
      var letter = String.fromCharCode(65 + i);
      label.appendChild(radio);
      label.appendChild(document.createTextNode(letter + ') ' + opt));
      label.htmlFor = id;
      optionsEl.appendChild(label);
    });

    updateScoreDisplay();
  }


  function onOptionSelect() {
    if (state.answered) return;
    var selected = document.querySelector('#options input[name="answer"]:checked');
    document.querySelectorAll('#options .option').forEach(function (el) {
      el.classList.toggle('selected', el.querySelector('input') === selected);
    });
    document.getElementById('next-btn').disabled = !selected;
  }

  /**
   * Submit current answer (on Next click): check, show feedback, schedule next.
   */
  function submitAnswer() {
    if (state.answered) return;
    var selected = document.querySelector('#options input[name="answer"]:checked');
    var q = QUESTIONS[state.currentIndex];
    var selectedIndex = selected ? parseInt(selected.value, 10) : -1;
    var correct = selectedIndex === q.correctIndex;
    if (correct) state.score++;
    state.answered = true;
    state.userAnswers.push({
      correct: correct,
      correctIndex: q.correctIndex,
      selectedIndex: selectedIndex
    });

    clearInterval(state.timerId);
    state.timerId = null;
    showFeedback(correct, q.correctIndex);
    updateScoreDisplay();
    scheduleNext();
  }

   
  function showResults() {
    showScreen('results-screen');
    var total = QUESTIONS.length;
    var pct = total === 0 ? 0 : Math.round((state.score / total) * 100);

    var finalScoreEl = document.getElementById('final-score');
    var percentageEl = document.getElementById('percentage');
    if (finalScoreEl) finalScoreEl.textContent = state.score + '/' + total;
    if (percentageEl) percentageEl.textContent = pct + '%';

    // Breakdown bar
    var correctBar = document.getElementById('correct-bar');
    var wrongBar = document.getElementById('wrong-bar');
    if (correctBar) correctBar.style.width = (state.score / total) * 100 + '%';
    if (wrongBar) wrongBar.style.width = ((total - state.score) / total) * 100 + '%';

    
    var celebrationEl = document.getElementById('celebration');
    if (celebrationEl) {
      if (pct >= HIGH_SCORE_THRESHOLD) {
        celebrationEl.textContent = '🎉 🏆 🌟';
        celebrationEl.style.display = 'block';
      } else {
        celebrationEl.style.display = 'none';
      }
    }
  }

  
  function startQuiz() {
    resetQuiz();
    showScreen('quiz-screen');
    renderQuestion();
    startQuestionTimer();
  }


  function init() {
    dom.startBtn = document.getElementById('start-btn');
    dom.nextBtn = document.getElementById('next-btn');
    dom.restartBtn = document.getElementById('restart-btn');

    if (dom.startBtn) dom.startBtn.addEventListener('click', startQuiz);
    if (dom.nextBtn) dom.nextBtn.addEventListener('click', submitAnswer);
    if (dom.restartBtn) dom.restartBtn.addEventListener('click', startQuiz);

  
    showScreen('start-screen');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
